//Nicholas Yudi Kurita Ikai 13671852
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        passwordGame newGame = new passwordGame();
        newGame.startGame();
    }
}
